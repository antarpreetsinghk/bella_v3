import json; lambda_handler = lambda event, context: {'statusCode': 200, 'body': json.dumps('Hello from Lambda\!')}

# app/services/llm.py
from __future__ import annotations

import asyncio
import json
import os
import re
from typing import Any, Dict, Optional

import httpx
from pydantic import BaseModel, Field, ValidationError

from app.core.config import settings
from app.core.performance import optimize_llm_call


# ---------- Public contract ----------

class ExtractedAppointment(BaseModel):
    full_name: Optional[str] = Field(None, description="Caller name (string)")
    mobile: Optional[str] = Field(None, description="E.164 or raw string; will be normalized later")
    starts_at: Optional[str] = Field(
        None,
        description="ISO8601 preferred; if natural language, model should convert to ISO"
    )
    duration_min: Optional[int] = Field(30, ge=1, le=240)
    notes: Optional[str] = None

    # helpful metadata for UX (not strictly required)
    missing: list[str] = Field(default_factory=list, description="Fields the model is unsure about")
    confidence: Optional[float] = Field(
        None, ge=0.0, le=1.0, description="Optional model self-estimate"
    )


# ---------- Helpers ----------

_JSON_FENCE_RE = re.compile(r"^```(?:json)?\s*(.*?)\s*```$", re.DOTALL | re.IGNORECASE)

def _strip_json_fences(s: str) -> str:
    m = _JSON_FENCE_RE.match(s.strip())
    return m.group(1) if m else s.strip()

def _coerce_json(s: str) -> Dict[str, Any]:
    s = _strip_json_fences(s)
    try:
        return json.loads(s)
    except Exception:
        brace_start = s.find("{")
        brace_end = s.rfind("}")
        if brace_start != -1 and brace_end != -1 and brace_end > brace_start:
            candidate = s[brace_start: brace_end + 1]
            try:
                return json.loads(candidate)
            except Exception:
                pass
    return {}

def _build_messages(transcript: str) -> list[dict[str, str]]:
    SYSTEM = (
        "You are an assistant that extracts dental appointment details from informal speech.\n"
        "Return ONLY a single JSON object with fields:\n"
        '{ "full_name": string|null, "mobile": string|null, "starts_at": string|null,'
        '  "duration_min": number|null, "notes": string|null, "missing": string[], "confidence": number|null }.\n'
        "Rules: Do not include any extra keys, commentary, or formatting. No markdown. No code fences."
    )
    USER = (
        "Transcript:\n"
        f"{transcript}\n\n"
        "Output requirements:\n"
        "- Normalize dates into ISO8601 if possible; if uncertain, set the field to null and list it in `missing`.\n"
        "- If phone number is spoken with words/spaces, keep as a single string; do not format beyond removing obvious delimiters.\n"
        "- Default duration_min to 30 if not specified.\n"
        "- Respond with JSON ONLY."
    )
    return [
        {"role": "system", "content": SYSTEM},
        {"role": "user", "content": USER},
    ]

def _openai_base_url() -> str:
    return (settings.OPENAI_BASE_URL or "https://api.openai.com").rstrip("/")


# ---------- Core call ----------

async def clean_and_enhance_speech(raw_speech: str) -> str:
    """
    Clean and enhance Twilio speech input before processing.

    Handles Canadian English variations, removes artifacts, expands contractions,
    and standardizes format for better downstream processing.
    """
    if not raw_speech or not raw_speech.strip():
        return raw_speech

    # LLM toggle (env can be "true"/"false"/"1"/"0")
    llm_enabled = str(os.getenv("LLM_ENABLED", "true")).lower() in {"1", "true", "yes", "on"}
    if not llm_enabled:
        # Simple fallback cleaning without LLM
        cleaned = raw_speech.strip()
        # Basic contractions
        cleaned = re.sub(r"\bit's\b", "it is", cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r"\bi'm\b", "i am", cleaned, flags=re.IGNORECASE)
        return cleaned

    base_url = _openai_base_url()
    model = getattr(settings, "OPENAI_MODEL", None) or "gpt-4o-mini"
    api_key = getattr(settings, "OPENAI_API_KEY", None)
    if not api_key:
        # Fallback to basic cleaning if no API key
        cleaned = raw_speech.strip()
        cleaned = re.sub(r"\bit's\b", "it is", cleaned, flags=re.IGNORECASE)
        return cleaned

    # Build cleaning prompt
    system_prompt = (
        "You are a speech cleaning assistant for Canadian voice systems. "
        "Clean and standardize speech input while preserving all meaningful information. "
        "Return ONLY the cleaned text, no explanations or formatting."
    )

    user_prompt = (
        f"Clean this speech input from Twilio speech-to-text:\n\n"
        f'"{raw_speech}"\n\n'
        f"Tasks:\n"
        f"1. Remove speech artifacts (um, uh, called her, etc.)\n"
        f"2. Remove conversational fillers (so what, what about, how about, let me see)\n"
        f"3. Expand contractions (it's → it is, I'm → I am)\n"
        f"4. Fix common Canadian speech patterns\n"
        f"5. Handle bilingual patterns (French-English mixing)\n"
        f"6. Standardize name introductions\n"
        f"7. Add missing area codes if obvious (e.g., 869-5838 → 204-869-5838 for Manitoba)\n"
        f"8. Preserve all meaningful content\n\n"
        f"Examples:\n"
        f'- "here, my name is antara, preet called her" → "my name is Antara Preet"\n'
        f'- "It\'s Johnny Smith" → "It is Johnny Smith"\n'
        f'- "Mon nom is Marie" → "My name is Marie"\n'
        f'- "86952338" → "204-869-2338" (if clearly a Manitoba number)\n\n'
        f"Return only the cleaned text:"
    )

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0.1,
        "max_tokens": 200,
    }

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    try:
        async with httpx.AsyncClient(base_url=base_url, timeout=10.0) as client:
            resp = await client.post("/v1/chat/completions", headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()
            cleaned_text = (data.get("choices") or [{}])[0].get("message", {}).get("content", "") or ""

            # Basic validation - if LLM returns something weird, use original
            if cleaned_text and len(cleaned_text.strip()) > 0 and len(cleaned_text) < len(raw_speech) * 3:
                return cleaned_text.strip()
            else:
                return raw_speech.strip()

    except Exception as e:
        # If LLM fails, return original with basic cleaning
        cleaned = raw_speech.strip()
        cleaned = re.sub(r"\bit's\b", "it is", cleaned, flags=re.IGNORECASE)
        return cleaned


async def unified_appointment_extraction(raw_speech: str, conversation_context: str = "") -> ExtractedAppointment:
    """
    UNIFIED LLM approach: Clean speech + extract appointment in ONE call.

    This replaces the multi-step process (clean_and_enhance_speech + extract_appointment_fields)
    with a single smart LLM call that handles everything:
    - Speech cleaning and artifact removal
    - Intelligent name matching (Interpret → Antarpreet)
    - Phone number normalization to E.164
    - Natural language date parsing to ISO8601
    - Canadian context awareness
    """
    if not raw_speech or not raw_speech.strip():
        raise ValueError("Raw speech is empty.")

    # LLM toggle (env can be "true"/"false"/"1"/"0")
    llm_enabled = str(os.getenv("LLM_ENABLED", "true")).lower() in {"1", "true", "yes", "on"}
    if not llm_enabled:
        return ExtractedAppointment(
            full_name=None,
            mobile=None,
            starts_at=None,
            duration_min=30,
            notes="[LLM disabled]",
            missing=["full_name", "mobile", "starts_at"],
            confidence=None,
        )

    base_url = _openai_base_url()
    model = getattr(settings, "OPENAI_MODEL", None) or "gpt-4o-mini"
    api_key = getattr(settings, "OPENAI_API_KEY", None)
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY is not set but LLM is enabled. Set LLM_ENABLED=false to disable in CI.")

    # Build unified extraction prompt
    system_prompt = (
        "You are a Canadian dental appointment booking assistant. Extract appointment details from "
        "potentially noisy Twilio speech-to-text input. You must clean the speech AND extract data in one step.\n\n"
        "Return ONLY a JSON object with these exact fields:\n"
        '{"full_name": string|null, "mobile": string|null, "starts_at": string|null, '
        '"duration_min": number|null, "notes": string|null, "missing": string[], "confidence": number|null}'
    )

    user_prompt = (
        f"RAW SPEECH FROM TWILIO: '{raw_speech}'\n"
        f"CONVERSATION CONTEXT: {conversation_context}\n\n"
        f"TASKS (all in one step):\n"
        f"1. CLEAN SPEECH: Remove artifacts (um, uh, called her), expand contractions (it's→it is)\n"
        f"   - IGNORE conversational phrases: 'so what', 'what about', 'how about', 'let me see', 'like I said'\n"
        f"   - These are NOT names - they are conversational fillers\n"
        f"2. INTELLIGENT NAME MATCHING: Common misheard Canadian names:\n"
        f"   - 'Interpret' or 'interpreter' → likely 'Antarpreet'\n"
        f"   - 'Until Preet' or 'under preet' → likely 'Antarpreet'\n"
        f"   - 'An Interpret' → likely 'Antarpreet'\n"
        f"   - Consider phonetic similarities for South Asian/Canadian names\n"
        f"   - NEVER extract 'so what', 'what about', 'how about' as names\n"
        f"3. PHONE NORMALIZATION: Convert to E.164 format (+1 for Canada)\n"
        f"   - Add area code 204 for Manitoba if missing (7-digit numbers)\n"
        f"   - Clean digits, remove formatting\n"
        f"4. DATE PARSING: Convert natural language to ISO8601 (YYYY-MM-DDTHH:MM:SS+00:00)\n"
        f"   - 'tomorrow at 2pm' → calculate actual date\n"
        f"   - 'Saturday' → next Saturday\n"
        f"   - Default timezone: America/Edmonton (MDT/MST)\n"
        f"5. VALIDATION: Only extract if reasonably confident\n\n"
        f"EXAMPLES:\n"
        f"Input: 'interpret calling for 2pm tomorrow, 204-555-1234'\n"
        f"Output: {{'full_name': 'Antarpreet', 'mobile': '+12045551234', 'starts_at': '2025-09-29T20:00:00+00:00', 'duration_min': 30, 'notes': null, 'missing': [], 'confidence': 0.9}}\n\n"
        f"Input: 'my name is until preet, 8695838'\n"
        f"Output: {{'full_name': 'Antarpreet', 'mobile': '+12048695838', 'starts_at': null, 'duration_min': 30, 'notes': null, 'missing': ['starts_at'], 'confidence': 0.8}}\n\n"
        f"Input: 'so what time is available? I need an appointment'\n"
        f"Output: {{'full_name': null, 'mobile': null, 'starts_at': null, 'duration_min': 30, 'notes': 'asking about available times', 'missing': ['full_name', 'mobile', 'starts_at'], 'confidence': 0.6}}\n\n"
        f"Return ONLY the JSON object:"
    )

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0.1,
        "max_tokens": 300,
        "response_format": {"type": "json_object"},
    }

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient(base_url=base_url, timeout=15.0) as client:
        resp = await client.post("/v1/chat/completions", headers=headers, json=payload)
        resp.raise_for_status()
        data = resp.json()
        text = (data.get("choices") or [{}])[0].get("message", {}).get("content", "") or ""
        obj = _coerce_json(text)

        if not obj:
            # Retry without JSON mode if parsing fails
            retry_payload = {**payload}
            retry_payload.pop("response_format", None)
            resp2 = await client.post("/v1/chat/completions", headers=headers, json=retry_payload)
            resp2.raise_for_status()
            data2 = resp2.json()
            text2 = (data2.get("choices") or [{}])[0].get("message", {}).get("content", "") or ""
            obj = _coerce_json(text2)

    # Ensure all required fields exist
    obj.setdefault("full_name", None)
    obj.setdefault("mobile", None)
    obj.setdefault("starts_at", None)
    obj.setdefault("duration_min", 30)
    obj.setdefault("notes", None)
    obj.setdefault("missing", [])
    obj.setdefault("confidence", None)

    try:
        parsed = ExtractedAppointment(**obj)
    except ValidationError as ve:
        # Fallback to minimal valid structure
        minimal = {
            "full_name": obj.get("full_name"),
            "mobile": obj.get("mobile"),
            "starts_at": obj.get("starts_at"),
            "duration_min": obj.get("duration_min") if isinstance(obj.get("duration_min"), (int, float)) else 30,
            "notes": obj.get("notes"),
            "missing": obj.get("missing") if isinstance(obj.get("missing"), list) else [],
            "confidence": obj.get("confidence") if isinstance(obj.get("confidence"), (int, float)) else None,
        }
        try:
            parsed = ExtractedAppointment(**minimal)
        except Exception as inner:
            raise RuntimeError(f"Unified LLM extraction failed: {ve}") from inner

    return parsed


@optimize_llm_call
async def extract_appointment_fields(transcript: str) -> ExtractedAppointment:
    """
    LEGACY function - kept for backward compatibility.
    Now delegates to unified_appointment_extraction.
    """
    return await unified_appointment_extraction(transcript)


# ---------- Simple CLI for local dev (optional) ----------

if __name__ == "__main__":
    example = (
        "Hey, this is John Smith. I'd like to book next Tuesday at 10 in the morning. "
        "My number is 587 555 0199. Make it a regular 30 minute cleaning."
    )

    async def _demo():
        result = await extract_appointment_fields(example)
        print(result.model_dump())

    asyncio.run(_demo())
